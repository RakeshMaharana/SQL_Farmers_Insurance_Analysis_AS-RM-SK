
-- CREATE TABLE IF NOT EXISTS FarmersInsuranceData (
--     rowID INT PRIMARY KEY,
--     srcYear INT,
--     srcStateName VARCHAR(255),
--     srcDistrictName VARCHAR(255),
--     InsuranceUnits INT,
--     TotalFarmersCovered INT,
--     ApplicationsLoaneeFarmers INT,
--     ApplicationsNonLoaneeFarmers INT,
--     InsuredLandArea FLOAT,
--     FarmersPremiumAmount FLOAT,
--     StatePremiumAmount FLOAT,
--     GOVPremiumAmount FLOAT,
--     GrossPremiumAmountToBePaid FLOAT,
--     SumInsured FLOAT,
--     PercentageMaleFarmersCovered FLOAT,
--     PercentageFemaleFarmersCovered FLOAT,
--     PercentageOthersCovered FLOAT,
--     PercentageSCFarmersCovered FLOAT,
--     PercentageSTFarmersCovered FLOAT,
--     PercentageOBCFarmersCovered FLOAT,
--     PercentageGeneralFarmersCovered FLOAT,
--     PercentageMarginalFarmers FLOAT,
--     PercentageSmallFarmers FLOAT,
--     PercentageOtherFarmers FLOAT,
--     YearCode INT,
--     Year_ VARCHAR(255),
--     Country VARCHAR(255),
--     StateCode INT,
--     DistrictCode INT,
--     TotalPopulation INT,
--     TotalPopulationUrban INT,
--     TotalPopulationRural INT,
--     TotalPopulationMale INT,
--     TotalPopulationMaleUrban INT,
--     TotalPopulationMaleRural INT,
--     TotalPopulationFemale INT,
--     TotalPopulationFemaleUrban INT,
--     TotalPopulationFemaleRural INT,
--     NumberOfHouseholds INT,
--     NumberOfHouseholdsUrban INT,
--     NumberOfHouseholdsRural INT,
--     LandAreaUrban FLOAT,
--     LandAreaRural FLOAT,
--     LandArea FLOAT
-- );


/*
    # --- Read_me: ---
    
    # Scaling Factor:
    --------------------------------------
    InsuredLandArea --------------- 1000
    FarmersPremiumAmount ---------- 100000
    StatePremiumAmount ------------ 100000
    GOVPremiumAmount -------------- 100000
    GrossPremiumAmountToBePaid ---- 100000
    SumInsured -------------------- 100000

    # EDA on DataSet:
    ------------------------------------------------------------------------------------------------------------------
    1. The dataset contains 1870 records and 44 columns.
        1.1. 50 Records in the dataset are not define and also not mentioned to use default value or NULL value.
        1.2. So only Total 1820 records are considered for analysis.

    # Column Description:
    ------------------------------------------------------------------------------------------------------------------ 
    SELECT COUNT(*) AS total_columns
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = 'ndap'
    AND TABLE_NAME = 'farmersinsurancedata';

    SELECT 
        COLUMN_NAME, ORDINAL_POSITION, COLUMN_DEFAULT, IS_NULLABLE, DATA_TYPE, 
        NUMERIC_PRECISION, NUMERIC_SCALE, COLUMN_TYPE, COLUMN_KEY
    FROM 
        INFORMATION_SCHEMA.COLUMNS
    WHERE 
        TABLE_SCHEMA = 'ndap'
    AND 
        TABLE_NAME = 'farmersinsurancedata';

*/

-- CREATE TABLE IF NOT EXISTS FarmersInsuranceData (
--     rowID INT PRIMARY KEY,
--     srcYear INT,
--     srcStateName VARCHAR(255),
--     srcDistrictName VARCHAR(255),
--     InsuranceUnits INT,
--     TotalFarmersCovered INT,
--     ApplicationsLoaneeFarmers INT,
--     ApplicationsNonLoaneeFarmers INT,
--     InsuredLandArea FLOAT,
--     FarmersPremiumAmount FLOAT,
--     StatePremiumAmount FLOAT,
--     GOVPremiumAmount FLOAT,
--     GrossPremiumAmountToBePaid FLOAT,
--     SumInsured FLOAT,
--     PercentageMaleFarmersCovered FLOAT,
--     PercentageFemaleFarmersCovered FLOAT,
--     PercentageOthersCovered FLOAT,
--     PercentageSCFarmersCovered FLOAT,
--     PercentageSTFarmersCovered FLOAT,
--     PercentageOBCFarmersCovered FLOAT,
--     PercentageGeneralFarmersCovered FLOAT,
--     PercentageMarginalFarmers FLOAT,
--     PercentageSmallFarmers FLOAT,
--     PercentageOtherFarmers FLOAT,
--     YearCode INT,
--     Year_ VARCHAR(255),
--     Country VARCHAR(255),
--     StateCode INT,
--     DistrictCode INT,
--     TotalPopulation INT,
--     TotalPopulationUrban INT,
--     TotalPopulationRural INT,
--     TotalPopulationMale INT,
--     TotalPopulationMaleUrban INT,
--     TotalPopulationMaleRural INT,
--     TotalPopulationFemale INT,
--     TotalPopulationFemaleUrban INT,
--     TotalPopulationFemaleRural INT,
--     NumberOfHouseholds INT,
--     NumberOfHouseholdsUrban INT,
--     NumberOfHouseholdsRural INT,
--     LandAreaUrban FLOAT,
--     LandAreaRural FLOAT,
--     LandArea FLOAT
-- );


/*
    # --- Read_me: ---
    
    # Scaling Factor:
    --------------------------------------
    InsuredLandArea --------------- 1000
    FarmersPremiumAmount ---------- 100000
    StatePremiumAmount ------------ 100000
    GOVPremiumAmount -------------- 100000
    GrossPremiumAmountToBePaid ---- 100000
    SumInsured -------------------- 100000

    # EDA on DataSet:
    ------------------------------------------------------------------------------------------------------------------
    1. The dataset contains 1870 records and 44 columns.
        1.1. 50 Records in the dataset are not define and also not mentioned to use default value or NULL value.
        1.2. So only Total 1820 records are considered for analysis.

    # Column Description:
    ------------------------------------------------------------------------------------------------------------------ 
    SELECT COUNT(*) AS total_columns
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = 'ndap'
    AND TABLE_NAME = 'farmersinsurancedata';

    SELECT 
        COLUMN_NAME, ORDINAL_POSITION, COLUMN_DEFAULT, IS_NULLABLE, DATA_TYPE, 
        NUMERIC_PRECISION, NUMERIC_SCALE, COLUMN_TYPE, COLUMN_KEY
    FROM 
        INFORMATION_SCHEMA.COLUMNS
    WHERE 
        TABLE_SCHEMA = 'ndap'
    AND 
        TABLE_NAME = 'farmersinsurancedata';

*/


use ndap;


-- ----------------------------------------------------------------------------------------------
-- SECTION 1. 
-- SELECT Queries [5 Marks]

-- 	Q1.	Retrieve the names of all states (srcStateName) from the dataset.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
-- <write your answers in the empty spaces given, the length of solution queries (and the solution writing space) can vary>

/*
    Query Design Notes:
	1. Objective: To list all unique state names from the dataset by selecting the srcStateName column from the FarmersInsuranceData table.
	2. Table Involved: FarmersInsuranceData
	3. Column Of Interest: srcStateName
	4. Goal: Return a distinct list of all state names without any repetitions.
*/
SELECT 
    DISTINCT srcStateName
FROM 
    FarmersInsuranceData;


-- ###

-- 	Q2.	Retrieve the total number of farmers covered (TotalFarmersCovered) 
-- 		and the sum insured (SumInsured) for each state (srcStateName), ordered by TotalFarmersCovered in descending order.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >


/*
    Query Design Notes:
    Objective: Retrieve the TotalFarmersCovered and the SumInsured for each state, and 
                display the result sorted by TotalFarmersCovered in descending order.
    Goal:
        1. Group records by state (srcStateName)
        2. Calculate aggregates for:
            2.1 Total farmers covered (TotalFarmersCovered)
            2.2.Total sum insured (SumInsured)
        3. Sort the result by the total farmers covered in descending order

    Note: As per column_description_analysis file, The scaling factor for;
        1. "SumInsured" = 100000 
*/

-- Without scaling
SELECT 
    srcStateName, 
    COALESCE(SUM(TotalFarmersCovered), 0) AS TotalFarmersCovered, 
    COALESCE(ROUND(SUM(SumInsured), 2), 0) AS TotalSumInsured
FROM 
    FarmersInsuranceData
GROUP BY 
    srcStateName
ORDER BY 
    TotalFarmersCovered DESC;

-- ###

-- --------------------------------------------------------------------------------------
-- SECTION 2. 
-- Filtering Data (WHERE) [15 Marks]

-- 	Q3.	Retrieve all records where Year is '2020'.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

/*
    Query Design Notes:
    Objective: To extract all records from the dataset where the year is 2020.
    Goal: All data only for the year 2020.
*/
SELECT *
FROM 
    FarmersInsuranceData
WHERE 
   srcYear = 2020;	

-- ###

-- 	Q4.	Retrieve all rows where the TotalPopulationRural is greater than 1 million and the srcStateName is 'HIMACHAL PRADESH'.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

/*
    Query Design Notes:
    Objective: To filter records based on two conditions:
        1. TotalPopulationRural > 1 million
        2. srcStateName = 'HIMACHAL PRADESH'
    Goal: To get all records that meet both conditions.
*/
SELECT *
FROM 
    FarmersInsuranceData
WHERE 
	TotalPopulationRural > 1000000
	AND srcStateName = 'HIMACHAL PRADESH';

-- ###

-- 	Q5.	Retrieve the srcStateName, srcDistrictName, and the sum of FarmersPremiumAmount for each district in the year 2018, 
-- 		and display the results ordered by FarmersPremiumAmount in ascending order.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

/*
    Query Design Notes:
    Objective: To retrieve the srcStateName, srcDistrictName, and the "sum of FarmersPremiumAmount" for each district in 2018.
    Goal: 
        1. Filter records for the year 2018
        2. Group by srcStateName and srcDistrictName
        3. Calculate the total FarmersPremiumAmount for each group
        4. Sort the results by FarmersPremiumAmount in ascending order

    Note: As per column_description_analysis file, The scaling factor for;
        1. "FarmersPremiumAmount" = 100000 

*/
-- With Up-Scaling
SELECT 
    srcStateName, 
    srcDistrictName, 
    ROUND(SUM(FarmersPremiumAmount * 100000), 2) AS TotalFarmersPremium
FROM 
    FarmersInsuranceData
WHERE 
    YearCode = 2018
GROUP BY 
    srcStateName, srcDistrictName
ORDER BY 
    TotalFarmersPremium ASC;


-- ###

-- 	Q6.	Retrieve the total number of farmers covered (TotalFarmersCovered) and the sum of premiums (GrossPremiumAmountToBePaid) for each state (srcStateName) 
-- 		where the insured land area (InsuredLandArea) is greater than 5.0 and the Year is 2018.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

/*
    Query Design Notes:
    Objective: To retrieve the total number of farmers covered and the sum of premiums for each state 
               where the insured land area is greater than 5.0 in 2018.
    Goal: 
        1. Filter records for 
            1.1. YearCode/srcYear = 2018
            1.2. InsuredLandArea > 5.0
        3. Group by srcStateName
        4. Calculate the total number of farmers covered and the sum of premiums

    Note: As per column_description_analysis file, The scaling factor for;
        1. GrossPremiumAmountToBePaid = 100000 
        2. InsuredLandArea = 1000
*/
-- With Up-Scaling (Only GrossPremiumAmountToBePaid)
SELECT 
    srcStateName, 
    ROUND(SUM(TotalFarmersCovered),2 ) AS TotalFarmersCovered, 
    ROUND(SUM(GrossPremiumAmountToBePaid * 100000), 2) AS TotalPremiums
FROM 
    FarmersInsuranceData
WHERE 
    InsuredLandArea > 5.0
    AND srcYear = 2018
GROUP BY 
    srcStateName;
	  
-- ###
-- ------------------------------------------------------------------------------------------------

-- SECTION 3.
-- Aggregation (GROUP BY) [10 marks]

-- 	Q7. 	Calculate the average insured land area (InsuredLandArea) for each year (srcYear).
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

/*
    Query Design Notes:
    Objective: To calculate the average insured land area for each year.
    Goal: 
        1. Group records by srcYear
        2. Calculate the average InsuredLandArea for each group

    Note: As per column_description_analysis file, The scaling factor for;
        1. "InsuredLandArea" = 1000
*/
-- With Up-Scaling
SELECT 
    srcYear as Year,  
    ROUND(AVG(InsuredLandArea * 1000), 2) AS AverageInsuredLandArea
FROM 
    FarmersInsuranceData
GROUP BY 
    srcYear;

-- ###

-- 	Q8. 	Calculate the total number of farmers covered (TotalFarmersCovered) for each district (srcDistrictName) where Insurance units is greater than 0.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >


/*
    Query Design Notes:
    Objective: To calculate the total number of farmers covered for each district where Insurance units are greater than 0.
    Goal: 
        1. Filter records where InsuranceUnits > 0
        2. Group by srcDistrictName
        3. Calculate the total number of farmers covered for each group

    Note: As per column_description_analysis file, The scaling factor for;
        1. "TotalFarmersCovered" = 100000
*/
-- Some districts share the same name across different states, so we need to group the data by both state and district.
-- SELECT 
-- 	srcDistrictName, 
--     COALESCE(SUM(TotalFarmersCovered), 0) AS TotalFarmersCovered
-- FROM 
-- 	FarmersInsuranceData
-- WHERE 
-- 	InsuranceUnits > 0
-- GROUP BY 
-- 	srcDistrictName;
	
-- Here, each combination of srcStateName + srcDistrictName is treated uniquely, even if the district name is the same across multiple states.
SELECT 
    srcStateName,
    srcDistrictName, 
    COALESCE(SUM(TotalFarmersCovered), 0) AS TotalFarmersCovered
FROM 
    FarmersInsuranceData
WHERE 
    InsuranceUnits > 0
GROUP BY 
    srcStateName,
    srcDistrictName;	 
    

-- ###

-- 	Q9.	For each state (srcStateName), calculate the total premium amounts (FarmersPremiumAmount, StatePremiumAmount, GOVPremiumAmount) 
-- 		and the total number of farmers covered (TotalFarmersCovered). Only include records where the sum insured (SumInsured) is greater than 500,000 (remember to check for scaling).
-- ###
-- 	[4 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

/*
    Query Design Notes:
    Objective: To calculate the total premium amounts and the total number of farmers covered for each state 
               where the sum insured is greater than 500,000.
    Goal: 
        1. Filter records where SumInsured > 500000
        2. Group by srcStateName
        3. Calculate the total premium amounts ("Consider individual single entity") 
           and the total number of farmers covered for each group.

    Note: As per column_description_analysis file, The scaling factor for;
        1. "FarmersPremiumAmount" = 100000
        2. "StatePremiumAmount" = 100000
        3. "GOVPremiumAmount" = 100000
        4. "SumInsured" = 100000
*/

-- With Up-Scaling
SELECT 
    srcStateName, 
    ROUND(SUM(FarmersPremiumAmount * 100000), 2) AS TotalFarmersPremium, 
    ROUND(SUM(StatePremiumAmount * 100000), 2) AS TotalStatePremium, 
    ROUND(SUM(GOVPremiumAmount * 100000), 2) AS TotalGovPremium, 
	SUM(TotalFarmersCovered) AS TotalFarmersCovered
FROM 
    FarmersInsuranceData
WHERE 
    (SumInsured * 100000) > 500000
GROUP BY 
    srcStateName;

-- ###

-- -------------------------------------------------------------------------------------------------
-- SECTION 4.
-- Sorting Data (ORDER BY) [10 Marks]

-- 	Q10.	Retrieve the top 5 districts (srcDistrictName) with the highest TotalPopulation in the year 2020.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >


/*
    Query Design Notes:
    Objective: To retrieve the top 5 districts with the highest total population in 2020.
    Goal: 
        1. Filter records for the year 2020
        2. Order by TotalPopulation in descending order
        3. Limit the result to the top 5 districts using DENSE_RANK()

    Note: As per column_description_analysis file, The scaling factor for;
        1. "TotalPopulation" = 100000

    ? Challenges:
        Some of the districts name is same in different states.

    SELECT 
        srcDistrictName,
        COUNT(DISTINCT srcStateName) AS stateCount,
        GROUP_CONCAT(DISTINCT srcStateName ORDER BY srcStateName SEPARATOR ', ') AS statesList
    FROM 
        FarmersInsuranceData
    GROUP BY 
        srcDistrictName
    HAVING 
        COUNT(DISTINCT srcStateName) > 1
    ORDER BY 
        srcDistrictName;

    Output:

    srcDistrictName     stateCount    statesList
    -----------------------------------------------------------------
    Bilaspur	        2	          CHHATTISGARH, HIMACHAL PRADESH
    Raigarh	            2	          CHHATTISGARH, MAHARASHTRA
    Balrampur	        2	          CHHATTISGARH, UTTAR PRADESH
    Hamirpur	        2	          HIMACHAL PRADESH, UTTAR PRADESH
    Pratapgarh	        2	          RAJASTHAN, UTTAR PRADESH

    Solution: 
        We can use the GROUP BY clause to group the records by srcStateName and srcDistrictName.
*/
SELECT 
	srcDistrictName,
    TotalPopulation
FROM 
    FarmersInsuranceData
WHERE 
    srcYear = 2020
ORDER BY 
    TotalPopulation DESC
LIMIT 5;

-- ###

-- 	Q11.	Retrieve the srcStateName, srcDistrictName, and SumInsured for the 10 districts with the lowest non-zero FarmersPremiumAmount, 
-- 		ordered by insured sum and then the FarmersPremiumAmount.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >


/*
    Query Design Notes:
    Objective: To retrieve the srcStateName, srcDistrictName, and SumInsured for the 10 districts with the lowest non-zero FarmersPremiumAmount.
    Goal: 
        1. Filter records where FarmersPremiumAmount > 0
        2. Order by SumInsured(o-1), FarmersPremiumAmount(o-2) in ascending order
        3. Limit the result to the top 10 districts using DENSE_RANK()
        4. Group by srcStateName and srcDistrictName

    Note: As per column_description_analysis file, The scaling factor for;
        1. "FarmersPremiumAmount" = 100000
        2. "SumInsured" = 100000
*/

-- With Up-Scaling
SELECT 
	srcStateName, 
	srcDistrictName, 
	SUM(SumInsured * 100000) AS TotalSumInsured, 
	SUM(FarmersPremiumAmount * 100000) AS TotalFarmersPremium
FROM 
	FarmersInsuranceData
WHERE 
	FarmersPremiumAmount > 0
GROUP BY 
	srcStateName, srcDistrictName
ORDER BY 
    TotalSumInsured, TotalFarmersPremium
LIMIT 10;


-- ###

-- 	Q12. 	Retrieve the top 3 states (srcStateName) along with the year (srcYear) where the ratio of insured farmers (TotalFarmersCovered) to the total population (TotalPopulation) is highest. 
-- 		Sort the results by the ratio in descending order.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >


/*
    SELECT NULLIF(0, 0);                                    > NULL
    SELECT NULLIF(100, 100);                                > NULL
    SELECT NULLIF(100, 0);                                  > 100
    SELECT NULLIF(0, 100);                                  > 0                 
    SELECT CASE WHEN 0 = 0 THEN 2000 / 0 ELSE 1 END;        > NULL

    -- SELECT 100/0; > NULL        Result depends upon SQL strict(Error: Division by zero)/ non-strict(NULL). SELECT @@sql_mode; 
    -- SELECT 0/100; > 0.0000

    -- SELECT NULL/100; > NULL
    -- SELECT 100/NULL; > NULL
*/

/*
    Query Design Notes:
    Objective: To retrieve the top 3 states along with the year where the ratio of insured farmers to the total population is highest.
    Goal: 
        1. Calculate the ratio of TotalFarmersCovered to TotalPopulation (TotalFarmersCovered / TotalPopulation)
        2. Order by the ratio in descending order
        3. Limit the result to the top 3 states using DENSE_RANK()
        4. Group by srcStateName and srcYear

    Note: As per column_description_analysis file, The scaling factor for;
        1. "TotalFarmersCovered" = 100000
        2. "TotalPopulation" = 100000
*/
WITH RankedStates AS (
    SELECT 
        srcStateName, 
        srcYear, 
        SUM(TotalFarmersCovered) / NULLIF(SUM(TotalPopulation), 0) AS INSURED_RATIO,
        DENSE_RANK() OVER (ORDER BY SUM(TotalFarmersCovered) / NULLIF(SUM(TotalPopulation), 0) DESC) AS INSURED_RATIO_DENSE_RANK
    FROM 
        FarmersInsuranceData
    WHERE 
        TotalPopulation > 0
    GROUP BY 
        srcStateName, srcYear
)
SELECT 
    srcStateName, srcYear, INSURED_RATIO
FROM 
    RankedStates
WHERE 
    INSURED_RATIO_DENSE_RANK <= 3;


-- ###

-- -------------------------------------------------------------------------------------------------

-- SECTION 5.
-- String Functions [6 Marks]

-- 	Q13. 	Create StateShortName by retrieving the first 3 characters of the srcStateName for each unique state.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >


/*
    Query Design Notes:
    Objective: To create a new column StateShortName by retrieving the first 3 characters of the srcStateName for each unique state.
    Goal: 
        1. Use the LEFT() function to extract the first 3 characters of srcStateName
        2. Select distinct values to avoid duplicates    
*/
SELECT 
	DISTINCT srcStateName, 
    LEFT(srcStateName, 3) AS StateShortName 
FROM 
	FarmersInsuranceData;

-- ###

-- 	Q14. 	Retrieve the srcDistrictName where the district name starts with 'B'.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

/*
    Query Design Notes:
    Objective: To retrieve the srcDistrictName where the district name starts with 'B'.
    Goal: 
        1. Use the LIKE operator to filter district names starting with 'B'
        2. Select distinct values to avoid duplicates

    ? Challenges:
        Some of the districts name is same in different states. 
*/
SELECT 
	DISTINCT srcDistrictName
FROM 
	FarmersInsuranceData
WHERE 
	srcDistrictName LIKE 'B%';

-- ###

-- 	Q15. 	Retrieve the srcStateName and srcDistrictName where the district name contains the word 'pur' at the end.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

/*
    Query Design Notes:
    Objective: To retrieve the srcStateName and srcDistrictName where the district name contains the word 'pur' at the end.
    Goal: 
        1. Use the LIKE operator to filter district names ending with 'pur'
        2. Select distinct values ( DISTINCT(srcStateName + srcDistrictName) ) to avoid duplicates

    ? Challenges:
        Some of the districts name is same in different states. 
*/
SELECT 
	DISTINCT srcStateName, 
    srcDistrictName
FROM 
	FarmersInsuranceData
WHERE 
	srcDistrictName LIKE '%pur';

-- ###

-- -------------------------------------------------------------------------------------------------

-- SECTION 6.
-- Joins [14 Marks]

-- 	Q16. 	Perform an INNER JOIN between the srcStateName and srcDistrictName columns to retrieve the aggregated FarmersPremiumAmount for districts where the district’s Insurance units for an individual year are greater than 10.
-- ###
-- 	[4 Marks]
-- ###
-- TYPE YOUR CODE BELOW >


/* 
    Query Design Notes:
    Objective: To perform an INNER JOIN between the srcStateName and srcDistrictName columns to retrieve the aggregated FarmersPremiumAmount for districts 
               where the district’s Insurance units for an individual year are greater than 10.
    Goal: 
        1. Perform an INNER JOIN on srcStateName and srcDistrictName
        2. Filter records where InsuranceUnits > 10
        3. Group by srcStateName, srcDistrictName, and srcYear (indivisual)
        4. Calculate the total FarmersPremiumAmount for each group

    Note: As per column_description_analysis file, The scaling factor for;
        1. "FarmersPremiumAmount" = 100000
*/
-- Without Scaling
SELECT 
    f1.srcStateName, 
    f1.srcDistrictName, 
    f1.srcYear, 
    ROUND(SUM(f1.FarmersPremiumAmount), 2) AS TotalFarmersPremium
FROM 
    FarmersInsuranceData f1 
INNER JOIN   
    (
        SELECT srcStateName, srcDistrictName, srcYear
        FROM FarmersInsuranceData
        GROUP BY srcStateName, srcDistrictName, srcYear
        HAVING SUM(InsuranceUnits) > 10
    ) f2
ON  
        f1.srcStateName     = f2.srcStateName 
    AND f1.srcDistrictName  = f2.srcDistrictName 
    AND f1.srcYear          = f2.srcYear
GROUP BY 
    f1.srcStateName, f1.srcDistrictName, f1.srcYear
ORDER BY 
    TotalFarmersPremium DESC;

-- ###

-- 	Q17.	Write a query that retrieves srcStateName, srcDistrictName, Year, TotalPopulation for each district and the the highest recorded FarmersPremiumAmount for that district over all available years
-- 		Return only those districts where the highest FarmersPremiumAmount exceeds 20 crores.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >


/* 
    Query Design Notes:
    Objective: To retrieve "srcStateName, srcDistrictName, Year, TotalPopulation" for each district and the highest recorded 
               FarmersPremiumAmount for that district over all available years.
               Return only those districts where the "Highest FarmersPremiumAmount" exceeds 20 cr.
    Goal: 
        1. Calculate the highest FarmersPremiumAmount for each district over all available years
        2. Filter records where the highest FarmersPremiumAmount > 20 crores
        3. Select srcStateName, srcDistrictName, Year, TotalPopulation

    Note: As per column_description_analysis file, The scaling factor for;
        1. "FarmersPremiumAmount" = 100000
*/
-- With Up-Scaling
WITH FarmersPremiumData AS (
    SELECT 
        srcStateName, 
        srcDistrictName, 
        srcYear AS Year, 
        TotalPopulation,
        FarmersPremiumAmount * 100000 AS ScaledFarmersPremiumAmount,
        ROW_NUMBER() OVER (
            PARTITION BY srcStateName, srcDistrictName 
            ORDER BY FarmersPremiumAmount DESC
        ) AS Rank_Number
    FROM FarmersInsuranceData
)
SELECT 
    srcStateName, 
    srcDistrictName, 
    Year, 
    TotalPopulation, 
    ScaledFarmersPremiumAmount AS HighestFarmersPremium,
    Rank_Number
FROM 
    FarmersPremiumData
WHERE 
    Rank_Number = 1
    AND ScaledFarmersPremiumAmount > 200000000
ORDER BY 
    HighestFarmersPremium DESC;

-- ###

-- 	Q18.	Perform a LEFT JOIN to combine the total population statistics with the farmers’ data (TotalFarmersCovered, SumInsured) for each district and state. 
-- 		Return the total premium amount (FarmersPremiumAmount) and the average population count for each district aggregated over the years, where the total FarmersPremiumAmount is greater than 100 crores.
-- 		Sort the results by total farmers' premium amount, highest first.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >


/*
    Query Design Notes:
    Objective: To perform a LEFT JOIN to combine the "total population" statistics with the farmers’ data (TotalFarmersCovered, SumInsured) for each district and state.
               Return the "total premium amount" and the "average population count" for each district aggregated over the years, 
               where the total FarmersPremiumAmount is greater than 100 crores.
    Goal: 
        1. Perform a LEFT JOIN on srcStateName and srcDistrictName
        2. Calculate the "average population count" for each district aggregated "over the years"
        3. Filter records where the "total FarmersPremiumAmount" > 100 crores
        4. Sort the results by "total farmers' premium amount" in descending order

    Note: AVG(TotalPopulation): Calculate the average population count for each district aggregated over the years. (include all years)

    Note: As per column_description_analysis file, The scaling factor for;
        1. "Farmers premium amount" = 100000
        2. "SumInsured" = 100000 

    -- read_me: 
    -- Perform a LEFT JOIN to combine the total population statistics with the farmers’ data 
    -- 		(TotalFarmersCovered, SumInsured) for each district and state. 
    -- Return the 
    --      total premium amount (FarmersPremiumAmount) and 
    --      the average population count for each district aggregated over the years, 
    --          where the total FarmersPremiumAmount is greater than 100 crores.
    -- Sort the results by total farmers' premium amount, highest first.  
*/
SELECT 
    fid.srcStateName, 
    fid.srcDistrictName, 
    AVG(INNER_TOTAL_POPULATION_AVG.TotalPopulation) AS AvgTotalPopulation,
    SUM(fid.TotalFarmersCovered) AS TotalFarmersCovered,
    SUM(fid.SumInsured) * 100000 AS TotalSumInsured,
    SUM(fid.FarmersPremiumAmount) * 100000 AS TotalFarmersPremium
FROM 
    FarmersInsuranceData fid
LEFT JOIN (
    SELECT 
        srcStateName, 
        srcDistrictName, 
        srcYear, 
        AVG(TotalPopulation) AS TotalPopulation
    FROM 
        FarmersInsuranceData
    GROUP BY 
        srcStateName, srcDistrictName, srcYear
) 
INNER_TOTAL_POPULATION_AVG 
    ON  fid.srcStateName        = INNER_TOTAL_POPULATION_AVG.srcStateName 
    AND fid.srcDistrictName     = INNER_TOTAL_POPULATION_AVG.srcDistrictName 
    AND fid.srcYear             = INNER_TOTAL_POPULATION_AVG.srcYear
GROUP BY 
    fid.srcStateName, fid.srcDistrictName
HAVING 
    SUM(fid.FarmersPremiumAmount) * 100000 > 1000000000
ORDER BY 
    TotalFarmersPremium DESC;


-- ###

-- -------------------------------------------------------------------------------------------------

-- SECTION 7.
-- Subqueries [10 Marks]

-- 	Q19.	Write a query to find the districts (srcDistrictName) where the TotalFarmersCovered is greater than the average TotalFarmersCovered across all records.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

/*
    Query Design Notes:
    Objective: To find the districts where the TotalFarmersCovered is greater than the average TotalFarmersCovered across all records.
    Goal: 
        1. Calculate the average TotalFarmersCovered across all records
        2. Filter records where TotalFarmersCovered > average
        3. Select srcStateName, srcDistrictName, and TotalFarmersCovered

    Note: As per column_description_analysis file, The scaling factor for;
        1. "TotalFarmersCovered" = 100000
*/
WITH AverageValue AS (
    SELECT AVG(TotalFarmersCovered) AS avgTotalFarmerCovered
    FROM FarmersInsuranceData
)
SELECT 
    srcStateName, 
    srcDistrictName, 
    SUM(TotalFarmersCovered) AS TotalFarmersCovered,
    av.avgTotalFarmerCovered,
    ROUND(SUM(TotalFarmersCovered) * 100.0 / av.avgTotalFarmerCovered, 2) AS percentage_of_avg
FROM 
    FarmersInsuranceData, AverageValue av
GROUP BY 
    srcStateName, srcDistrictName, av.avgTotalFarmerCovered
HAVING 
    SUM(TotalFarmersCovered) > av.avgTotalFarmerCovered
ORDER BY 
    TotalFarmersCovered DESC;


-- ###

-- 	Q20.	Write a query to find the srcStateName where the SumInsured is higher than the SumInsured of the district with the highest FarmersPremiumAmount.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

/*
    Query Design Notes:
    Objective: To find the srcStateName where the SumInsured is higher than the SumInsured of the district with the highest FarmersPremiumAmount.
    Goal: 
        1. Calculate the maximum FarmersPremiumAmount for each district (TOP District by using Limit 1)
        2. Filter records where SumInsured > maximum FarmersPremiumAmount
        3. Select srcStateName and SumInsured

    Note: As per column_description_analysis file, The scaling factor for;
        1. "FarmersPremiumAmount" = 100000
        2. "SumInsured" = 100000
*/
WITH MaxFarmersPremiumAmountDistrict AS (
    SELECT 
		srcDistrictName, 
        srcStateName, 
        SUM(SumInsured) AS MaxStateDistrictSumInsured
    FROM 
		FarmersInsuranceData
    GROUP BY 
		srcStateName, srcDistrictName
    ORDER BY 
		SUM(FarmersPremiumAmount) DESC
    limit 1
)
SELECT 
	f.srcStateName, 
    SUM(f.SumInsured) AS StateTotalSumInsured
FROM 
	FarmersInsuranceData f JOIN MaxFarmersPremiumAmountDistrict mpd ON 1=1  -- cross join (assign individual record to another single record of next table)
GROUP BY 
	f.srcStateName 
HAVING 
	SUM(f.SumInsured) > (SELECT MaxStateDistrictSumInsured FROM MaxFarmersPremiumAmountDistrict)
ORDER BY 
	StateTotalSumInsured DESC;


-- ###

-- 	Q21.	Write a query to find the srcDistrictName where the FarmersPremiumAmount is higher than the average FarmersPremiumAmount of the state that has the highest TotalPopulation.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

/*
    Query Design Notes:
    Objective: To find the srcDistrictName where the FarmersPremiumAmount is higher than the average FarmersPremiumAmount of the state that has the highest TotalPopulation.
    Goal: 
        1. Calculate the average FarmersPremiumAmount for the state with the highest TotalPopulation
        2. Filter records where FarmersPremiumAmount > average
        3. Select srcStateName, srcDistrictName, and FarmersPremiumAmount

    Note: As per column_description_analysis file, The scaling factor for;
        1. "FarmersPremiumAmount" = 100000
*/
SELECT DISTINCT
	srcStateName,
    srcDistrictName,
    FarmersPremiumAmount
FROM 
	FarmersInsuranceData
WHERE 
	FarmersPremiumAmount > 
    (
		SELECT 
			ROUND(AVG(FarmersPremiumAmount),2) AS avgFarmersPremiumAmount
		FROM 
            FarmersInsuranceData
		WHERE 
            srcStateName = (
                SELECT 
                    srcStateName
                FROM 
                    FarmersInsuranceData
                GROUP BY
                    srcStateName
                ORDER BY 
                    AVG(TotalPopulation) DESC
                LIMIT 1
		)
    );

-- ###

-- -------------------------------------------------------------------------------------------------

-- SECTION 8.
-- Advanced SQL Functions (Window Functions) [10 Marks]

-- 	Q22.	Use the ROW_NUMBER() function to assign a row number to each record in the dataset ordered by total farmers covered in descending order.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >


/*
    Query Design Notes:
    Objective: To assign a row number to each record in the dataset ordered by total farmers covered in descending order.
    Goal: 
        1. Use the ROW_NUMBER() function to assign a row number
        2. Order by TotalFarmersCovered in descending order
*/
SELECT 
    ROW_NUMBER() OVER (
	-- PARTITION BY srcStateName 
    ORDER BY TotalFarmersCovered DESC) AS row_num, fid.* 
FROM 
    FarmersInsuranceData fid;


-- ###

-- 	Q23.	Use the RANK() function to rank the districts (srcDistrictName) based on the SumInsured (descending) and partition by alphabetical srcStateName.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

/*
    Query Design Notes:
    Objective: To rank the districts based on the SumInsured (descending) and partition by alphabetical srcStateName.
    Goal: 
        1. Use the RANK() function to assign a rank
        2. Partition by srcStateName
        3. Order by SumInsured in descending order
*/
-- Without Scaling
WITH DistrictSumInsured AS (
    SELECT 
        srcStateName, 
        srcDistrictName, 
        SUM(SumInsured) AS TotalSumInsured
    FROM FarmersInsuranceData
    GROUP BY srcStateName, srcDistrictName
),
RankedDistricts AS (
    SELECT 
        srcStateName, 
        srcDistrictName, 
        ROUND(TotalSumInsured, 2) as TotalSumInsured,
        RANK() OVER (PARTITION BY srcStateName ORDER BY TotalSumInsured DESC) AS Rank_Number
    FROM DistrictSumInsured
)
SELECT *
FROM RankedDistricts
ORDER BY srcStateName ASC;

-- ###

-- 	Q24.	Use the SUM() window function to calculate a cumulative sum of FarmersPremiumAmount for each district (srcDistrictName), ordered ascending by the srcYear, partitioned by srcStateName.
-- ###
-- 	[4 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

/*
    Query Design Notes:
    Objective: To calculate a cumulative sum of FarmersPremiumAmount for each district, ordered ascending by the srcYear, partitioned by srcStateName.
    Goal: 
        1. Use the SUM() window function to calculate a cumulative sum
        2. Partition by srcStateName
        3. Order by srcYear in ascending order
*/
SELECT 
    srcStateName, 
    srcDistrictName, 
    srcYear, 
    FarmersPremiumAmount,
    ROUND(
        SUM(FarmersPremiumAmount) OVER (
        PARTITION BY srcStateName, srcDistrictName 
        ORDER BY srcYear ASC
        ), 2
    ) AS CumulativeFarmersPremiumAmount
FROM FarmersInsuranceData;
-- ORDER BY srcStateName, srcDistrictName, srcYear;


-- ###

-- -------------------------------------------------------------------------------------------------

-- SECTION 9.
-- Data Integrity (Constraints, Foreign Keys) [4 Marks]

-- 	Q25.	Create a table 'districts' with DistrictCode as the primary key and columns for DistrictName and StateCode. 
-- 		Create another table 'states' with StateCode as primary key and column for StateName.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

/*
    Query Design Notes:
    Objective: To create two tables 'districts' and 'states' with specified columns and primary keys.
    Goal: 
        1. Create the 'states' table with StateCode as primary key and StateName
        2. Create the 'districts' table with DistrictCode as primary key, DistrictName, and StateCode

    Here, we are creating two tables with the following columns:
        1. states table:
            - StateCode (INT, Primary Key)
            - StateName (VARCHAR(100), NOT NULL)
        2. districts table:
            - DistrictCode (INT, Primary Key)
            - DistrictName (VARCHAR(100), NOT NULL)
            - StateCode (INT, NOT NULL)    

    Note: As per dataset max length of StateName and DistrictName are below;
        1. SELECT MAX(CHAR_LENGTH(srcDistrictName)) AS maxDistrictNameLength FROM FarmersInsuranceData;  -- 27
        2. SELECT MAX(CHAR_LENGTH(srcStateName))    AS maxStateNameLength FROM FarmersInsuranceData;     -- 27
    So, we can use VARCHAR(45) for both columns.

*/
CREATE TABLE states (
    StateCode INT PRIMARY KEY,
    StateName VARCHAR(45) NOT NULL
);

CREATE TABLE districts (
    DistrictCode INT PRIMARY KEY,
    DistrictName VARCHAR(45) NOT NULL,
    StateCode INT NOT NULL
);

-- ###

-- 	Q26.	Add a foreign key constraint to the districts table that references the StateCode column from a states table.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

ALTER TABLE districts 
ADD CONSTRAINT FK_CONTRAINTS_DISTRICTS_STATES 
FOREIGN KEY (StateCode) 
REFERENCES states(StateCode) 
ON DELETE CASCADE 
ON UPDATE CASCADE;

-- ###

-- -------------------------------------------------------------------------------------------------

-- SECTION 10.
-- UPDATE and DELETE [6 Marks]

-- 	Q27.	Update the FarmersPremiumAmount to 500.0 for the record where rowID is 1.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

/*
    Note: 
        As per dataset, rowID is not a valid record, so it will not update any record.
        Few issues in data whether how can we treat the blank values in the dataset(null/ default value).

        So, just for the sake of this question, writing the query to update the record.
*/
UPDATE  FarmersInsuranceData
SET     FarmersPremiumAmount = 500.0
WHERE   rowID = 1;


-- ###

-- 	Q28.	Update the Year to '2021' for all records where srcStateName is 'HIMACHAL PRADESH'.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

UPDATE  FarmersInsuranceData
SET     srcYear = 2021
WHERE   srcStateName = 'HIMACHAL PRADESH';

-- ###

-- 	Q29.	Delete all records where the TotalFarmersCovered is less than 10000 and Year is 2020.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

DELETE FROM FarmersInsuranceData
WHERE  TotalFarmersCovered < 10000 
AND    srcYear = 2020;

-- ###